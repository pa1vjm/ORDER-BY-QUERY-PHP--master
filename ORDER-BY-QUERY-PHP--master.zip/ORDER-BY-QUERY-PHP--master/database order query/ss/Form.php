<!DOCTYPE html>
<html>
<body>
<head>
<title> Sample Form with PHP+ MYSQL</title>
</head>
<h2>Intern Simple Input field</h2>

<form action="insert.php"  method="POST" enctype="multipart/form-data">

 Enter Your Name:<br>
  <input  type="text" name="name" id="name">
  <br><br>
  <input type="submit" id="submit" name="submit">
</form>

</body>
</html>

